import datetime
from odoo import fields, api, models


class CarPicking(models.TransientModel):

    _name = "car.picking.wizard"
    _description = "Car Picking Wizard"

    @api.model
    def default_get(self, fields):
        res = super(CarPicking, self).default_get(fields)
        res['pick_date'] = datetime.date.today()
        if self.env.context.get('active_id'):
            res['request_id'] = self.env.context.get('active_id')
        return res

    request_id = fields.Many2one(string='Request', comodel_name='movement.request', readonly=True)
    car_id = fields.Many2one(string='Car', comodel_name='car', domain=[('state', '=', 'available')], required=True)
    description = fields.Text(string="Description")
    pick_date = fields.Datetime(string='Picking Date')
    pick_end_date = fields.Datetime(string='Picking End Date')

    def action_pick(self):
        active_id = self._context.get('active_id')
        move = self.env['movement.request'].browse(active_id)
        self.request_id.state = '3'
        self.request_id.logistic_check_date = fields.Datetime.now()
        self.request_id.logistic_check = self.env.user.name
        move.car_id = self.car_id
        self.car_id.state = 'reserved'
        self.car_id.start_time = self.request_id.leave_time
        self.car_id.end_time = self.pick_end_date
        vals = {
                'car_id': self.car_id.id,
                'reason': 'Picking for: ' + self.request_id.purposes,
                'old_state': 'available',
                'new_state': 'reserved',
                'change_date': self.request_id.leave_time,
                # Add any other relevant fields
        }
        car = self.env['car.history'].browse(self.car_id.id)
        car.create(vals)
        return {
            'type': 'ir.actions.client',
            'tag': 'reload',
        }

