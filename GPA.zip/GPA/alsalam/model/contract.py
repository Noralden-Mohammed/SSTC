from dateutil.utils import today

from odoo import models,api,fields
from datetime import date,timedelta,datetime

from odoo.addons.test_convert.tests.test_env import field, record
from odoo.addons.test_impex.tests.test_load import message
from odoo.exceptions import ValidationError


class Hr(models.Model):



    _inherit = 'hr.contract'



    def action_set_to_open(self):
        self.write({'state':'open'})
        print("iam here")


    def action_set_to_expired(self):
        self.write({'state': 'close'})

    def action_set_to_cancelled(self):
        self.write({'state': 'cancel'})


    def action_set_to_new(self):
        self.write({'state':'draft'})

    def check_contract_expiry(self):
        expired_contracts = self.search([('date_end','<=',date.today())])
        for contract in expired_contracts:
            print("this contract is expired")
            contract.write({'state':'close'})



    @api.constrains('employee_id','state')
    def check_employee_contract_state(self):
        for contract in self:
                if contract.state=='open':
                    other_contracts = self.env['hr.contract'].search([('employee_id','=',contract.employee_id.id),('state','=','open'),('id','!=',contract.id)])
                    if other_contracts:
                      raise ValidationError("The employee cannot have more than one active contract at the same time")

    @api.model
    def check_contract_end_date(self):
        print('expiry date')
        today=datetime.today().date()
        target_date= (datetime.today()+timedelta(days=30)).date()
        contracts= self.search([('date_end','<=',target_date),('date_end','>=',today)])
        for contract in contracts :
            message_content= f"the contract of employee  {contract.employee_id.name} is nearly end at {contract.date_end}"
            message = {
                'subject':'notification of employee contract end date',
                'body': message_content,
                'res_id':contract.id,
                'model':'hr.contract',
                'message_type':'comment',
                'subtype_id': self.env.ref('mail.mt_comment').id,
            }
            print('hellooooooooo')
            self.env['mail.message'].create(message)
            partner_ids = [user.partner_id.id for user in self.env['res.users'].search([('share','=',False)])]
            self.env['mail.message'].create({
                'subject':'notification of contract end date',
                'body': message_content,
                'partner_ids':[(6,0,partner_ids)],
                'message_type':'notification'
            })
            print("hiiiiiiiiiiiiii")
            user=self.env.ref('base.user_admin')
            activity_type=self.env['mail.activity.type'].search([],limit=1)
            activity={
                'res_model_id':self.env['ir.model']._get('hr.contract').id,
                'res_id':contract.id,
                'activity_type_id':activity_type.id,
                'summary':'contract end date notification',
                'note': f"the contract of  employee {contract.employee_id.name} is nearly ending at {contract.date_end}",
                'date_deadline': contract.date_end,
                'user_id':user.id,
            }
            print('the enddddddddd')
            self.env['mail.activity'].create(activity)

