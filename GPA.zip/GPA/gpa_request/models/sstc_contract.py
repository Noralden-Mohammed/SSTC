from odoo import models, fields, api


class HrContract(models.Model):
    _inherit = 'hr.contract'

    founded_by = fields.Char(string="Founded By",tracking=True)
    project = fields.Many2one('account.analytic.account', tracking=True)

    def action_set_running(self):
        # Implement your state change logic here
        for contract in self:
            contract.state = 'open'  # Replace 'new_state' with your desired state
        return True

    def action_set_expired(self):
        # Implement your state change logic here
        for contract in self:
            contract.state = 'close'  # Replace 'new_state' with your desired state
        return True

    def action_set_cancel(self):
        # Implement your state change logic here
        for contract in self:
            contract.state = 'cancel'  # Replace 'new_state' with your desired state
        return True
