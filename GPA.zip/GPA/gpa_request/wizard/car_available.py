import datetime
from odoo import fields, api, models


class CarAvailable(models.TransientModel):

    _name = "car.available.wizard"
    _inherit = 'car'
    _description = "Car Available Wizard"

    @api.model
    def default_get(self, fields):
        res = super(CarAvailable, self).default_get(fields)
        res['change_date'] = datetime.date.today()
        if self.env.context.get('active_id'):
            res['car_id'] = self.env.context.get('active_id')
        return res

    car_id = fields.Many2one('car', readonly=True)
    old_state = fields.Char()
    new_state = fields.Char()
    change_date = fields.Date()
    reason = fields.Char(required=True)



    def change_car_state(self):
        active_id = self._context.get('active_id')
        car = self.env['car'].browse(active_id)
        if car:
            # Create a record in car.history
            self.env['car.history'].create({
                'car_id': car.id,
                'reason': self.reason,
                'old_state': 'unavailable',
                'new_state': 'available',
                'change_date': self.change_date,
                # Add any other relevant fields
            })
            # Update the state of the car
            car.write({'state': 'available'})


