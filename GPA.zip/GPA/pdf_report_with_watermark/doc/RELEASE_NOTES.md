## Module <pdf_report_with_watermark>
#### 04.03.2024
#### Version 17.0.1.0.0
##### ADD
- Initial Commit for Reports With Watermark

#### 05.09.2024
#### Version 17.0.1.1.1
##### ADD
- Bug Fix