{
    'name': 'GPA Program Manager ',
    'author': "Noralden Mohammed (SSTC) ",
    'category': "GPA",
    'version': '1.0',
    'depends': ['base','hr'],
    'data': [
        'security/ir.model.access.csv',
        'views/program_manager.xml',

    ],
    'application': True,

}
