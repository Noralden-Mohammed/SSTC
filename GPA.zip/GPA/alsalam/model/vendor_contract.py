from odoo import fields ,models




class VendorContract(models.Model):


    _name = 'vendor.contract'
    _rec_name = 'partner_id'


    contract= fields.Text(no_label='1')
    description= fields.Text(nolabel='1')
    address1 = fields.Char(string='Address')
    represented = fields.Many2one( 'res.users',string='Represented by')
    partner_id = fields.Many2one('res.partner',string='Represented by')
    company_name = fields.Char(related='partner_id.company_id.name',string="second party representative")
    address2 = fields.Char(string="Address")
    contracter_name=fields.Char(string="Represented by")
    scope_of_work= fields.Text(string="1. Scope of work")
    payment_terms= fields.Text(string="2. PaymentTerms")
    implementation_time_frame = fields.Text(string="3. Implementation Timeframe")
    responsibilities = fields.Text(string="4. Responsibilities")
    termination = fields.Text(string="5. Termination")
    governing_low =fields.Text(string="6. Governing Low")
    dispute_resolution = fields.Text(string="7. Dispute Resolution")
    contracter1_name= fields.Char(string="Name")
    signature1 = fields.Char("Signature")
    Date1 = fields.Date(string="Date")
    contracter2_name= fields.Char(string="name")
    signature2 = fields.Char("Signature")
    Date2 = fields.Date(string="Date")







