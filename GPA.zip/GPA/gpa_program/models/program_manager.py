from odoo import models, fields, api
import random



class ProgramManager(models.Model):
    _name = 'gpa.program'
    _inherit = ['mail.thread', 'mail.activity.mixin']


    name = fields.Char(string='Project Name', required=True, tracking=True)
    code = fields.Char(string='Project Code', required=True, tracking=True)
    founded_by = fields.Char(string='Founded by', required=True, tracking=True)
    partner_ids = fields.One2many(comodel_name='res.partner', inverse_name='gpa_program_id', string="Partner",
                                  tracking=True)
    target = fields.Char(string='Target', required=True, tracking=True)
    objective = fields.Text(string='Objective', required=True, tracking=True)
    # employee_ids = fields.One2many(comodel_name='hr.employee', inverse_name='gpa_program_id', string="Employee")
    budget = fields.Monetary(string='Budget', required=True, tracking=True)
    # activity = fields.One2many(comodel_name='gpa.activity', inverse_name='gpa_program_id', required=True, tracking=True,
    #                             string="Activity")
    start_date = fields.Date(string='Start Date', required=True, tracking=True)
    end_date = fields.Date(string='End Date', required=True, tracking=True)
    project_type = fields.Selection(selection=[('chps', 'CHPs'), ('edu', 'Education'),  ('emergency', 'Emergency Activity'),
                                               ('gpv', 'GPV'), ('other', 'Others')], required=True, tracking=True)
    progress = fields.Integer(string='Progress', compute="_compute_progress")
    state = fields.Selection(selection=[('draft', 'Draft'), ('in_progress', 'In Progress'), ('done', 'Done'),
                                        ('cancel', 'Canceled')], default="draft", tracking=True)
    priority = fields.Selection([
        ('0', 'Normal'),
        ('1', 'Low'),
        ('2', 'High'),
        ('3', 'Very High')], string="Priority", tracking=True)

    @api.depends('state')
    def _compute_progress(self):
        for rec in self:
            progress = 0
            if rec.state == 'draft':
                progress = 0
            elif rec.state == 'in_progress':
                progress = random.randrange(50, 99)
            elif rec.state == 'done':
                progress = 100
            elif rec.state == 'cancel':
                progress = progress
            rec.progress = progress




class HREmployee(models.Model):
    _inherit = 'hr.employee'

    gpa_program_id = fields.Many2one(comodel_name='gpa.program', string="GPA")



class GPAActivity(models.Model):
    _name = 'gpa.activity'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string='Name', required=True, tracking=True)
    code = fields.Char(string='Code', required=True, tracking=True)
    gpa_program_id = fields.Many2one(comodel_name='gpa.program', string="GPA")
    start_date = fields.Date(string="Start Date", required=True, tracking=True)
    end_date = fields.Date(string="End Date", required=True, tracking=True)
    progress = fields.Integer(string="Progress", tracking=True)



