from odoo import models, fields, api
import datetime


class RequestReject(models.TransientModel):
    _name = 'request.reject'

    request_id = fields.Many2one('requisition.request', string="Request")
    date = fields.Date(string="Date", required=True)
    reason = fields.Char(string="Reason", required=True)

    @api.model
    def default_get(self, fields):
        res = super(RequestReject, self).default_get(fields)
        res['date'] = datetime.date.today()
        if self.env.context.get('active_id'):
            res['request_id'] = self.env.context.get('active_id')
        return res

    def action_reject(self):
        self.request_id.state = '4'
        self.request_id.reason = self.reason
        return {
            'type': 'ir.actions.client',
            'tag': 'reload',
        }


