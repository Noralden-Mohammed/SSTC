from odoo import models,fields


class ResPartner(models.Model):
    _inherit = 'res.partner'

    vendors_id = fields.Many2one('vendor.contract')

    def action_make_contract(self):
        action = self.env['ir.actions.actions']._for_xml_id('alsalam.vendor_contract_action')
        view_id = self.env.ref('alsalam.vendor_contract_form_view').id
        action['res_id'] = self.vendors_id.id
        action['views'] = [[view_id, 'form']]
        return action



