from odoo import models, api, fields

class PurchaseRequest(models.Model):
    _name = 'purchase.request'
    _description = 'Purchase Request'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _rec_name = 'requester_id'

    name_req = fields.Char(string='Request Reference', readonly= True, default= 'New')
    requester_id = fields.Many2one('res.users', string="Requester", default=lambda self: self.env.user, tracking=True)
    department = fields.Selection([
        ('operation', 'Operation'),
        ('program', 'Program'),
    ], string="Department", tracking=True)
    request_date = fields.Date(string="Request Date", default=fields.Date.today(), tracking=True)
    #program_officer_id = fields.Many2one('res.users', string='Program Officer',required=1,tracking=True)
    finance = fields.Char(string="Finance Check")
    approver = fields.Char(string="Manager")
    program_officer_date = fields.Datetime()
    finance_date = fields.Datetime()
    approver_date = fields.Datetime()
    counter = fields.Integer(counter='Counter')
    reason = fields.Text(string="Reject Reason", tracking=True, readonly=True)
    total = fields.Float(string='Total',  compute='_compute_total_1', store=1)
    description = fields.Char(string="Description", tracking=True)
    state = fields.Selection([('draft','Draft'),
                              ('pm_check','Program Manager Check'),
                              ('wa','Waiting For Approve'),
                              ('am_check','Area Manager Check'),
                              ('fi_check','Finance Check'),
                              ('cancel', 'Cancelled'),
                              ('done','Done')
                              ],string='Status',required=1,default='draft')

    line_ids = fields.One2many('product.line', 'requests_id', string="Approved By")
    total_in_words=fields.Char(string='Total Price (in words)',compute='_compute_total_in_words')

    def action_draft(self):
        self.write({'state': 'draft'})

    def action_pm_check(self):
        self.write({'state': 'pm_check'})

    def action_confirm(self):
        self.write({'state' : 'wa'})

    def action_am_check(self):
        self.write({'state': 'am_check'})

    def action_approve(self):
        for rec in self:
            rec.state = 'fi_check'
            rec.approver_date = fields.Datetime.now()
            rec.approver = self.env.user.name

    def action_finance_check(self):
        for rec in self:
            rec.state = 'done'
            rec.finance_date = fields.Datetime.now()
            rec.finance = self.env.user.name
            return {
                'effect': {
                    'fadeout': 'slow',
                    'message': 'The Request Done successfully :)',
                    'type': 'rainbow_man',
                }
            }

    def action_reject(self):
        action = self.env.ref('al_salam_organization.request_reject_action').read()[0]
        return action

    @api.depends('line_ids.total_2')
    def _compute_total_1(self):
      for rec in self:
          rec.total = sum(rec.line_ids.mapped('total_2'))

    @api.depends(total)
    def _compute_total_in_words(self):
        for rec in self:
           if rec.total and rec.currency_id:
                rec.total_in_words = rec.currency_id.amount_to_text(rec.total)
           else :
             rec.total_in_words=' '

    @api.model
    def create(self, vals):
        res = super(PurchaseRequest, self).create(vals)
        if res.name_req == 'New':
           res.name_req = self.env['ir.sequence'].next_by_code('purchase_request_seq')
        return res

    class ProductLine(models.Model):
        _name = 'product.line'
        requests_id = fields.Many2one('purchase.request', string='Request')
        product_id = fields.Many2one('product.template', string='Item')
        description = fields.Char(string="Description")
        qit = fields.Float(string='Quantity')
        price = fields.Float(string='Price',related='product_id.standard_price', readonly=False)
        total_2= fields.Float(string='Total',  compute='_compute_total_2')

        @api.depends('price','qit')
        def _compute_total_2(self):
            for rec in self:
                rec.total_2 = rec.price * rec.qit






