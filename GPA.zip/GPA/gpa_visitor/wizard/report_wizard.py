from datetime import date
import logging
from odoo import fields, api, models
from odoo.exceptions import UserError


_logger = logging.getLogger(__name__)


class RequestReportWizard(models.TransientModel):

    _name = "visitor.report.wizard"

    user_id = fields.Many2one('res.users')
    request_id = fields.Many2one('gpa.visitor')

    start_date = fields.Date(string='Date From', required=True, default=fields.Date.today())
    end_date = fields.Date(string='Date To', required=True, default=fields.Date.today())

    # def get_requests(self):
    def get_report(self):
        # requests = self.env['movement.request'].get_requests_between_dates(self.start_date, self.end_date)
        # domain = self.env['requisition.request'].search([('request_date', '>=', self.start_date), ('request_date', '<=', self.end_date),('state', '=', '5')])
        domain = []
        if self.start_date:
            domain.append(('date', '>=', self.start_date))

        if self.end_date:
            domain.append(('date', '<=', self.end_date))


        res = self.env['gpa.visitor'].search(domain)
        if not res:
            raise UserError('No records found pleas check your selected date.')
        _logger.info('Requests found: %s', res)
        # return self.env.ref('requisition.request').search(domain)
        return self.env.ref('gpa_visitor.report_visitor_wizard').report_action(res)

    # def get_report(self):
    #     data = {
    #         'model': self._name,
    #         'form': self.read(['start_date', 'end_date', 'project_id'])[0]
    #     }
    #     return self.env.ref('sstc_altwaki_project.report_request').report_action(self, data=data)
