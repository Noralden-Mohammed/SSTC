{
    'name': 'GPA Visitor Manager ',
    'author': "Noralden Mohammed (SSTC) ",
    'category': "GPA",
    'version': '1.0',
    'depends': ['base','mail','hr'],
    'data': [
        'security/ir.model.access.csv',
        'wizard/report_wizard.xml',
        'views/visitor.xml',
        'report/visitor_report.xml',
        'report/visitor_report_wizard.xml',
    ],
    'application': True,
    'installable': True,

}
