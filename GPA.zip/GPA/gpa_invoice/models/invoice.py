from odoo import models, fields, api
import random



class ProgramManager(models.Model):
    _inherit = "account.move"


    def print_voucher_cash(self):
        print("-----------------------")


class ReportInvoiceWithAnalytics(models.AbstractModel):
    _name = 'report.gpa_invoice.invoice_report_template'
    _description = 'Customer Invoice with Analytic Accounts'

    @api.model
    def _get_report_values(self, docids, data=None):
        docs = self.env['account.move'].browse(docids)

        # Fetch analytic account names for each invoice line
        for move in docs:
            for line in move.invoice_line_ids:
                if line.analytic_distribution:
                    line.analytic_display = [
                        (self.env['account.analytic.account'].browse(int(analytic_id)).name, percentage)
                        for analytic_id, percentage in line.analytic_distribution.items()
                    ]

        return {
            'doc_ids': docids,
            'doc_model': 'account.move',
            'docs': docs,
        }



