from odoo import models, fields, api


class MovementRequest(models.Model):
    _name = 'movement.request'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _rec_name = 'name_id'

    ref = fields.Char(readonly=1, default='New')
    name_id = fields.Many2one('res.users', string="Name", default=lambda self: self.env.user, tracking=True)
    program_id = fields.Many2one('account.analytic.account', string="Activity", tracking=True)
    personal = fields.Char(string="Personal", tracking=True)
    request_date = fields.Date(string="Request Date", default=fields.Date.today(), tracking=True)
    leave_time = fields.Datetime(string="Leave", required=True, tracking=True)
    logistic_check_date = fields.Datetime()
    operation_manager_date = fields.Datetime()
    program_manager_date = fields.Datetime()
    approved_by_date = fields.Datetime()
    logistic_check = fields.Char(string="Logistic Officer")
    operation_manager = fields.Char(string="Operation Manager")
    program_manager = fields.Char(string="Program Manager")
    approved_by = fields.Char(string="Approved By")
    destination = fields.Char(string="Destination", required=True, tracking=True)
    purposes = fields.Char(string="Purposes", required=True, tracking=True)
    qit = fields.Integer(string="Passenger Quantity", tracking=True)
    description = fields.Text(string="Description", tracking=True)
    car_id = fields.Many2one('car', string="Car Picking", tracking=True)
    state = fields.Selection([
        ('0', 'Draft'),
        ('1', 'Waiting For Approve'),
        ('2', 'Logistic Check'),
        ('3', 'Manager Approved'),
        ('4', 'Reject'),
        ('5', 'Ready'),
    ], string="Status", default='0', required=True, tracking=True)

    def action_draft(self):
        for rec in self:
            rec.state = '0'

    def action_confirm(self):
        for rec in self:
            rec.state = '1'

    def action_logistic_check(self):
        action = self.env.ref('gpa_request.car_picking_action').read()[0]
        return action

    def action_final_approve(self):
        for rec in self:
            rec.state = '5'
            rec.approved_by_date = fields.Datetime.now()
            rec.approved_by = self.env.user.name
            return {
                'effect': {
                    'fadeout': 'slow',
                    'message': 'The Request Done successfully :)',
                    'type': 'rainbow_man',
                }
            }

    def action_reject(self):
        for rec in self:
            rec.state = '4'

    def action_approve(self):
        for rec in self:
            rec.state = '2'
            rec.program_manager_date = fields.Datetime.now()
            rec.program_manager = self.env.user.name

    @api.model
    def create(self, vals):
        res = super(MovementRequest, self).create(vals)
        if res.ref == 'New':
            res.ref = self.env['ir.sequence'].next_by_code('movement_request_seq')
        return res


    @api.model
    def get_requests_between_dates(self, start_date, end_date):
        requests = self.search([('request_date', '>=', start_date), ('request_date', '<=', end_date)])
        return requests