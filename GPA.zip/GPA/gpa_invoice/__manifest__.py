{
    'name': 'GPA vousher report ',
    'author': "Noralden Mohammed (SSTC) ",
    'category': "GPA",
    'version': '1.0',
    'depends': ['base','account'],
    'data': [
        'report/fleet_report_a4.xml',
        'report/payment_requset.xml',
        'report/print_invoice_a4.xml',
        'report/invoice_report.xml',

    ],
    'application': True,

}
