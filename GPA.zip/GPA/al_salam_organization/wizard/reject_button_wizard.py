from odoo import models,fields,api
import datetime

class RejectBWizard(models.TransientModel):
    _name = 'reject.wizard'

    pr_request_id = fields.Many2one('purchase.request',string='Purchase Request')
    date_of_request = fields.Date(string='Date',required=1)
    reason = fields.Char(string='Reason', required=1)

    @api.model
    def default_get(self, fields):
        res = super(RejectBWizard, self).default_get(fields)
        res['date_of_request'] = datetime.date.today()
        if self.env.context.get('active_id'):
            res['pr_request_id'] = self.env.context.get('active_id')
        return res

    def action_reject(self):
        self.pr_request_id.state = 'cancel'
        self.pr_request_id.reason = self.reason
        self.pr_request_id.request_date = self.date_of_request
        return {
            'type': 'ir.actions.client',
            'tag': 'reload',
        }
