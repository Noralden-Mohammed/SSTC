from odoo import models, fields, api, _
from odoo.exceptions import ValidationError


class HrEmployee(models.Model):
    _inherit = 'hr.employee'

    emp_code = fields.Char(size=12, required=True)
    user_id = fields.Many2one('res.users', string='User', readonly=True)

    # @api.model
    # def create(self, vals):
    #     employee = super(HrEmployee, self).create(vals)
    #     # Create a user based on employee data
    #     self.create_user_from_employee(employee)
    #     return employee

    # def create_user_from_employee(self, employee):
        # user = self.env['res.users']
        # groups = self.env.ref('gpa_request.requisition_request_user_group', 'base.group_user')
        # if 'work_email' in employee and employee['work_email']:
        #     existing_user = self.env['res.users'].search([('login', '=', employee['work_email'])])
        #     print("////////////////////////////////////////////////////")
        #     if existing_user:
        #         print("????????????????????????????????????????????????????????")
        #         raise ValidationError(_('A user with this email already exists.'))
        #     user_values = {
        #         'name': employee.name,
        #         'image_1920': employee.image_1920,
        #         'login': employee.work_email,  # Use work email as login
        #         'password': employee.emp_code,  # password to login
        #         'employee_id': employee.id,  # employee
        #         'department_id': employee.department_id.id,  # Department
        #         'groups_id': [(4, groups.id)],  # No access rights
        #         'partner_id': employee.address_id.id if employee.address_id else False,
        #         # Add more fields as required
        #     }
        #     user.create(user_values)
        #     print("###############################################################")
        #     employee.user_id = user.id
    @api.model
    def create(self, vals):
        # Call the original create method to create the employee
        employee = super(HrEmployee, self).create(vals)
        # Check if work_email is provided and is a string
        work_email = vals.get('work_email', '').strip() if isinstance(vals.get('work_email'), str) else ''
        if work_email:
            existing_user = self.env['res.users'].search([('login', '=', work_email)])
            if existing_user:
                raise ValidationError(_('A user with this email already exists.'))

            # Create a new user with validated fields
            user_vals = {
                'name': vals.get('name', '').strip() if isinstance(vals.get('name'), str) else '',
                'login': work_email,
                'email': work_email,
                'password': '123',
                'image_1920': vals.get('image_1920', False),
                'partner_id': employee.address_id.id if employee.address_id else False,
            }
            user = self.env['res.users'].create(user_vals)
            print("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%")
            # Link the user to the employee
            employee.user_id = user.id
            print("||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||")
        return employee
