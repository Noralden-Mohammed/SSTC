from odoo import models,fields,api

class PurchaseOrderCustom(models.Model):
    _inherit = 'purchase.order'

    Date = fields.Date()
    Vendor_id = fields.Many2one('res.partner', string="Suppler Name")
    approved_by = fields.Many2one('res.users' ,string="Approved by")
    sig1 = fields.Char(string="Signature")
    sig2 = fields.Char(string="Signature")
    prepared_by = fields.Many2one('res.users', string="Prepared by")
    date_demand = fields.Date(string="Date")
    date_delivary = fields.Date(string="Date")
    signature_prepared=fields.Char(string="Signature")
    suppler_stamp = fields.Char(string="Suppler stamp for acceptable")






