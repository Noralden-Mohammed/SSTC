from odoo import models,fields

class PurchaseOrderRfqInhiret(models.Model):
    _inherit = 'purchase.order'

    Date = fields.Date()
#supplier
    Vendor_id =      fields.Many2one('res.partner', string="Suppler Name")
    # Vendor_address = fields.Char(related="contact.street", string="Address",readonly=True)
    # phone =          fields.Char(related="suppler_contact.phone",string="Phone",readonly=True)
    # suppler_id =     fields.Char(related="suppler_contact.x_id_number",string="ID Number",readonly=True)
    signature_s =    fields.Char(string='Signature')
    date =           fields.Date(string='Date',default=fields.Date.today())
#Area Manager
    approved_by=        fields.Many2one('res.users', string="Approved_by")
    position_a =        fields.Many2one('hr.job',string="Position")
    Approval_signature= fields.Char(string='Signature')
    approved_date=      fields.Date(string='Date',default=fields.Date.today())
#logistic
    review_id =  fields.Many2one('res.users', string="Reviewed by")
    position_l=  fields.Many2one('hr.job',string="Position")
    signature_l= fields.Char(string='Signature')
    review_date= fields.Date(string='Date',default=fields.Date.today())

