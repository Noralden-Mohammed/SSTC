from . import contract
from . import res_partner
from . import vendor_contract
from . import home