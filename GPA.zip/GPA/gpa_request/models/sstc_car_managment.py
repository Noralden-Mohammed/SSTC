from odoo import models, fields, api
from datetime import date, datetime


class CarManagement(models.Model):
    _name = 'car'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _rec_name = 'ref'

    requests_id = fields.Many2one('requisition.request', string="Request")

    car_no = fields.Char(tracking=True, required=True)
    ref = fields.Char(tracking=True, default='New', readonly=True)
    car_models_id = fields.Many2one('car.model', string="Car Model", tracking=True, required=True)
    car_color_id = fields.Many2one('car.color', string="Car Color", tracking=True)
    car_size = fields.Integer(tracking=True, string="Passenger Number", required=True)
    description = fields.Text(string="Description", tracking=True)
    car_availability = fields.Boolean(default=True, tracking=True)
    state = fields.Selection([
        ('available', 'Available'),
        ('unavailable', 'Unavailable'),
        ('reserved', 'Reserved'),
    ], default="available", tracking=True)
    start_time = fields.Datetime(tracking=True, string="Picking Start Time", readonly=True)
    end_time = fields.Datetime(tracking=True,string="Picking End Time", readonly=True)
    image = fields.Image()
    active = fields.Boolean(string="Active", default=True, tracking=True)
    car_history_ids = fields.One2many('car.history', 'car_id', string="Car History")

    @api.model
    def create(self, vals):
        res = super(CarManagement, self).create(vals)
        if res.ref == 'New':
            res.ref = self.env['ir.sequence'].next_by_code('car_seq')
        return res

    @api.model
    def update_car_states(self):
        today = fields.Datetime.now()
        cars_to_update = self.env['car'].search([('end_time', '<=', today), ('state', '=', 'reserved')])
        for car in cars_to_update:
            car.write({'state': 'available'})

    def button_available(self):
        action = self.env.ref('gpa_request.car_available_action').read()[0]
        return action

    def button_unavailable(self):
        action = self.env.ref('gpa_request.car_unavailable_action').read()[0]
        return action


class CarColor(models.Model):
    _name = 'car.color'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(tracking=True, required=True)
    code = fields.Char(tracking=True, required=True)
    active = fields.Boolean(string="Active", default=True, tracking=True)
    color = fields.Float(string="Tags")


class CarModel(models.Model):
    _name = 'car.model'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(tracking=True, required=True)
    code = fields.Char(tracking=True, required=True)
    active = fields.Boolean(string="Active", default=True, tracking=True)
    color = fields.Integer(string="Tags")


class CarHistory(models.Model):
    _name = "car.history"
    _inherit = ['mail.thread', 'mail.activity.mixin']

    car_id = fields.Many2one('car', readonly=True)
    old_state = fields.Char()
    new_state = fields.Char()
    change_date = fields.Datetime()
    reason = fields.Char()