from odoo import models, fields, api, _


class SSTCPurchaseOrder(models.Model):
    _inherit = 'purchase.order'

    partner_id = fields.Many2one('res.partner', string="Vendor")
    finance_check = fields.Char()
    operation_manager = fields.Char()
    area_manager = fields.Char()
    logistic_officer = fields.Char()
    finance_check_date = fields.Datetime()
    operation_manager_date = fields.Datetime()
    area_manager_date = fields.Datetime()
    logistic_officer_date = fields.Datetime()
    STATE_SELECTION = [
        ('draft', 'RFQ'),
        ('sent', 'RFQ Sent'),
        ('finance_check', 'Finance Check'),
        ('operation_manager', 'Operation Manager Approve'),
        ('area_manager', 'Area Manager Approve'),
        ('purchase', 'Purchase Order'),
        ('done', 'Locked'),
        ('cancel', 'Cancelled')
    ]

    state = fields.Selection(STATE_SELECTION, string='Status', readonly=True, copy=False, index=True,
                             track_visibility='onchange', default='draft')

    def action_confirm_rfq(self):
        self.state = 'finance_check'

    def action_finance_check(self):
        self.state = 'operation_manager'

    def action_operation_manager(self):
        self.state = 'area_manager'

    def action_area_manager(self):
        # res = super(SSTCPurchaseOrder, self).button_confirm()
        for order in self:
            if order.state not in ['draft', 'sent', 'finance_check', 'operation_manager', 'area_manager']:
                continue
            order.order_line._validate_analytic_distribution()
            order._add_supplier_to_product()
            # Deal with double validation process
            if order._approval_allowed():
                order.button_approve()
            else:
                order.write({'state': 'to approve'})
            if order.partner_id not in order.message_partner_ids:
                order.message_subscribe([order.partner_id.id])
        return True



