{
'name': 'contracts',
 'author': 'Buthaina mohamed',
 'depends': ['base','mail','hr','hr_contract','contacts'],
'data':[
    'security/ir.model.access.csv',
    'views/contract.xml',
    'views/contact.xml',
    'views/vendor_contract.xml',
    'views/visit_form.xml',
    'views/menu.xml',
    'report/vendor_contract.xml',
     "report/visit_report.xml",

],
'application': True,
  'installable': True,
 }