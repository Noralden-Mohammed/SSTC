from odoo import fields,models


class HomeVisitForm(models.Model):
    _name = 'home'
    _description = 'home visit form'


    homeowner_name = fields.Char(string='اسم مالك المنزل')
    familymembers_number=fields.Integer(string='عدد افراد الاسرة')
    water_source = fields.Char(string='مصدر الماء')
    water_transport_container1 = fields.Boolean(string='نظيف')
    water_transport_container2 = fields.Boolean(string='غير نظيف')
    water_storage_container1 = fields.Boolean(string='نظيف')
    water_storage_container2 = fields.Boolean(string='غير نظيف')
    water_storage_container3 = fields.Boolean(string='مغطى')
    water_storage_container4 = fields.Boolean(string='غير مغطى')
    toilet1 = fields.Boolean(string='موجود')
    toilet2 = fields.Boolean(string='غير موجود')
    toilet_state1 = fields.Boolean(string='نظيف')
    toilet_state2 = fields.Boolean(string='غير نظيف')
    toilet_state3 = fields.Boolean(string='ماء-صابون')
    animal_pen1 = fields.Boolean(string='موجود')
    animal_pen2 = fields.Boolean(string='غير موجود')
    house_environment1 = fields.Boolean(string='براز انسان')
    house_environment2 = fields.Boolean(string='براز حيوان')
    waste_disposal_method1 = fields.Boolean(string='حرق')
    waste_disposal_method2 = fields.Boolean(string='دفن')
    waste_disposal_method3 = fields.Boolean(string='رمي عشوائي')




