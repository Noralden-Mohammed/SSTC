{
'name' : 'Al_salam Org',
'author' :'Amal Yassir, odoo Developer',
'category' : '',
'version':'17.0.0.1.0',
'depends':['base','mail','purchase','stock','hr'
    ],
'data':[
    'security/ir.model.access.csv',
    'security/security.xml',
    'data/sequence.xml',
    'views/purchase_request.xml',
    # 'views/purchase_rfq.xml',
    #'views/purchase_order.xml',

    'wizard/reject_button_wizard_view.xml',
    'views/base_menu.xml',
    'reports/pr_report.xml',

],
'application': True,
'installable': True,
}
