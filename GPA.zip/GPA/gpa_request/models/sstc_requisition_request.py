from odoo import models, fields, api


class RequisitionRequest(models.Model):
    _name = 'requisition.request'
    _rec_name = 'name_id'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    ref = fields.Char(readonly=1, default='New')
    name_id = fields.Many2one('res.users', string="Name", default=lambda self: self.env.user, tracking=True)
    department = fields.Selection([
        ('operation', 'Operation'),
        ('program', 'Program'),
    ], string="Department", tracking=True)
    program_id = fields.Many2one('account.analytic.account', string="Activity", tracking=True)
    program_ref = fields.Char(string="Code", related="program_id.code", tracking=True)
    request_date = fields.Date(string="Request Date", default=fields.Date.today(), tracking=True)
    finance_check_date = fields.Datetime()
    operation_manager_date = fields.Datetime()
    approved_by_date = fields.Datetime()
    finance_check = fields.Char(string="Finance Check")
    operation_manager = fields.Char(string="Operation Manager")
    program_manager = fields.Char(string="Program Manager")
    approved_by = fields.Char(string="Approved By")
    item_ids = fields.One2many('product.line', 'requests_id', string="Approved By")
    total = fields.Float(string="Total", compute='_compute_total', store=True)
    description = fields.Text(string="Description", tracking=True)
    reason = fields.Text(string="Reject Reason", tracking=True, readonly=True)
    state = fields.Selection([
        ('0', 'Draft'),
        ('1', 'Finance Check'),
        ('2', 'Waiting For Approve'),
        ('3', 'Manager Approved'),
        ('4', 'Reject'),
        ('5', 'Done'),
    ], string="Status", default='0', required=True, tracking=True)

    def action_draft(self):
        for rec in self:
            rec.state = '0'

    def action_confirm(self):
        for rec in self:
            rec.state = '1'

    def action_finance_check(self):
        for rec in self:
            rec.state = '2'
            rec.finance_check_date = fields.Datetime.now()
            rec.finance_check = self.env.user.name

    def action_final_approve(self):
        for rec in self:
            rec.state = '5'
            rec.approved_by_date = fields.Datetime.now()
            rec.approved_by = self.env.user.name
            return {
                'effect': {
                    'fadeout': 'slow',
                    'message': 'The Request Done successfully :)',
                    'type': 'rainbow_man',
                }
            }

    def action_reject(self):
        action = self.env.ref('gpa_request.request_reject_action').read()[0]
        return action

    def action_approve(self):
        for rec in self:
            rec.state = '3'
            rec.operation_manager_date = fields.Datetime.now()
            rec.operation_manager = self.env.user.name

    def action_print(self):
        for rec in self:
            rec.state = '3'
            rec.operation_manager_date = fields.Datetime.now()
            rec.operation_manager = self.env.user.name

    @api.model
    def create(self, vals):
        res = super(RequisitionRequest, self).create(vals)
        if res.ref == 'New':
            res.ref = self.env['ir.sequence'].next_by_code('requisition_request_seq')
        return res

    @api.depends('item_ids.sup_total')
    def _compute_total(self):
        for rec in self:
            rec.total = sum(rec.item_ids.mapped('sup_total'))



    # @api.model
    # def get_report_data(self, start_date, end_date):
    #     records = self.search([('request_date', '>=', start_date), ('request_date', '<=', end_date)])
    #     return records


class ProductItem(models.Model):
    _name = 'product.line'

    requests_id = fields.Many2one('requisition.request', string="Request")
    product_id = fields.Many2one('product.template', string="Item")
    price_unit = fields.Float(string="Price", related='product_id.standard_price', readonly=False)
    sup_total = fields.Float(string="Total", compute='_compute_sup_total')
    qit = fields.Integer(string="Quantity")
    description = fields.Char(string="Description")

    @api.depends('price_unit', 'qit')
    def _compute_sup_total(self):
        for rec in self:
            rec.sup_total = rec.price_unit * rec.qit


    # default = lambda self: self._get_default_price()
    # @api.depends('product_id')
    # def _get_default_price(self):
    #     if self.product_id:
    #         return self.product_id.list_price
    #     else:
    #         return 0.0
