from odoo import models, fields, api



class GPAVisitor(models.Model):
    _name = 'gpa.visitor'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _rec_name = 'partner_id'

    partner_id = fields.Many2one(comodel_name='res.partner', string="Name", required=True, tracking=True)
    company = fields.Char(string="Company")
    phone = fields.Char(default=lambda self: self._default_phone(), string="Phone", tracking=True, readonly=False)
    employee_id = fields.Many2one(comodel_name='hr.employee', string="Employee Visitor", required=True, tracking=True)
    purposes = fields.Char(string="Purposes", required=True, tracking=True)
    date = fields.Datetime(string="Date", required=True, tracking=True)
    note = fields.Text(string="Note", tracking=True, help="Type any note ")

    @api.model
    def _default_phone(self):
        if self.partner_id:
            return self.partner_id.phone
        return ''

    @api.onchange('partner_id')
    def _onchange_partner_id(self):
        if self.partner_id:
            self.phone = self.partner_id.phone
        else:
            self.phone = ''

