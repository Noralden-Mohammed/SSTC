from odoo import models, fields


class AccountMoveInherit(models.Model):
    _inherit = 'account.move'

    STATE_SELECTION = [
        ('draft', 'Draft'),
        ('approve_finance', 'Finance Officer Approve'),
        ('operation_manager_approve', 'Operation Manager Approve'),
        ('manager_approve', 'Manager Approve'),
        ('posted', 'Posted'),
        ('cancel', 'Cancelled')
    ]
    state = fields.Selection(STATE_SELECTION, string='Status', readonly=True, copy=False, index=True,
                             track_visibility='onchange', default='draft')

    def button_approve_finance(self):
        for move in self:
            move.state = 'approve_finance'

    def button_approve_finance_officer(self):
        for move in self:
            move.state = 'operation_manager_approve'

    def button_operation_manager_approve(self):
        for move in self:
            move.state = 'manager_approve'

    def button_manager_approve(self):
        res = super(AccountMoveInherit,self).action_post()
        for move in self:
            move.state = 'posted'
        return res


# class AccountMoveDraftWizard(models.TransientModel):
#     _name = 'account.move.wizard'
#     _inherit = 'account.move'
#
#     ref = fields.Char(string="Reference")
#     date = fields.Datetime(default=fields.datetime.now(), required=True)
#     reason = fields.Char(required=True)
#     move_id = fields.Many2one('account.move', string="Invoice/Bill No")
#
#     def reset_to_draft(self):
#         res = super(AccountMoveDraftWizard, self).button_draft()
#         return res

